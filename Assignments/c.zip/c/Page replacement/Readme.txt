See "pagereplacement_output.pdf" for more details

cc pagereplacement.c 
./a.out

Enter page numbers required for the process.
Enter modify bit corresponding to each page.
Enter option for each algorithm to execute.

Output:

Step by step for each algorithm(Its very big!!!)

Summary at end.

